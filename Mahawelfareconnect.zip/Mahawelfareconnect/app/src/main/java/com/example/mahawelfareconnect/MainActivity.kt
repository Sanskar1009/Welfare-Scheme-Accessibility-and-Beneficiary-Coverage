package com.example.mahawelfareconnect

import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

data class Scheme(
    val title: String,
    val department: String,
    val description: String,
    val category: String,
    val documents: String
)

class MainActivity : AppCompatActivity() {

    private lateinit var schemeList: LinearLayout
    private lateinit var searchBox: EditText
    private lateinit var categorySpinner: Spinner
    private lateinit var sectionTitle: TextView

    private val schemes = listOf(

        Scheme(
            "Mukhyamantri Majhi Ladki Bahin Yojana",
            "Women and Child Development",
            "Financial assistance to eligible women in Maharashtra.",
            "Women",
            "• Aadhaar Card\n" +
                    "• Maharashtra Domicile Certificate or applicable residence proof\n" +
                    "• Income Certificate, where applicable\n" +
                    "• Ration Card\n" +
                    "• Bank Account / Passbook details\n" +
                    "• Passport-size Photograph\n" +
                    "• Beneficiary Undertaking"
        ),

        Scheme(
            "Lek Ladki Yojana",
            "Women and Child Development",
            "Financial support for eligible girl children.",
            "Women & Children",
            "• Birth Certificate of beneficiary\n" +
                    "• Family Income Certificate\n" +
                    "• Beneficiary Aadhaar Card\n" +
                    "• Parent Aadhaar Card\n" +
                    "• Bank Passbook\n" +
                    "• Yellow or Orange Ration Card\n" +
                    "• School / College Bonafide Certificate\n" +
                    "• Family Planning Certificate, where applicable"
        ),

        Scheme(
            "Education Scholarship Schemes",
            "Education Department",
            "Scholarship support for eligible students.",
            "Education",
            "• Aadhaar Card\n" +
                    "• Domicile Certificate\n" +
                    "• Income Certificate\n" +
                    "• Admission / Bonafide Certificate\n" +
                    "• Educational Qualification Documents\n" +
                    "• Bank Account Details\n" +
                    "• Other documents as required by the specific scholarship"
        ),

        Scheme(
            "Social Welfare Schemes",
            "Social Justice Department",
            "Welfare programs for eligible citizens from different social groups.",
            "Social Welfare",
            "• Aadhaar Card\n" +
                    "• Caste Certificate, where applicable\n" +
                    "• Income Certificate\n" +
                    "• Domicile / Residence Proof\n" +
                    "• Bank Account Details\n" +
                    "• Ration Card, where applicable\n" +
                    "• Other documents according to the scheme"
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        schemeList = findViewById(R.id.schemeList)
        searchBox = findViewById(R.id.searchBox)
        categorySpinner = findViewById(R.id.categorySpinner)
        sectionTitle = findViewById(R.id.sectionTitle)

        setupNavigation()
        setupSearch()
        setupCategory()

        // Show schemes directly when the app opens
        showSchemes()
    }

    // ---------------- NAVIGATION ----------------

    private fun setupNavigation() {

        findViewById<Button>(R.id.btnSchemes).setOnClickListener {
            showSchemes()
        }

        findViewById<Button>(R.id.btnEligibility).setOnClickListener {
            showEligibility()
        }

        findViewById<Button>(R.id.btnAnalytics).setOnClickListener {
            showAnalytics()
        }

        findViewById<Button>(R.id.btnAbout).setOnClickListener {
            showAbout()
        }
    }

    // ---------------- SEARCH ----------------

    private fun setupSearch() {

        searchBox.addTextChangedListener(object : TextWatcher {

            override fun beforeTextChanged(
                s: CharSequence?,
                start: Int,
                count: Int,
                after: Int
            ) {
            }

            override fun onTextChanged(
                s: CharSequence?,
                start: Int,
                before: Int,
                count: Int
            ) {
                filterSchemes()
            }

            override fun afterTextChanged(s: Editable?) {
            }
        })
    }

    // ---------------- CATEGORY ----------------

    private fun setupCategory() {

        val categories = arrayOf(
            "All Categories",
            "Women",
            "Women & Children",
            "Education",
            "Social Welfare"
        )

        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            categories
        )

        categorySpinner.adapter = adapter

        categorySpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    filterSchemes()
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {
                }
            }
    }

    // ---------------- SHOW SCHEMES ----------------

    private fun showSchemes() {

        searchBox.visibility = View.VISIBLE
        categorySpinner.visibility = View.VISIBLE

        sectionTitle.text = "Available Welfare Schemes"

        filterSchemes()
    }

    // ---------------- FILTER ----------------

    private fun filterSchemes() {

        if (!::schemeList.isInitialized) {
            return
        }

        schemeList.removeAllViews()

        val searchText =
            searchBox.text.toString().trim().lowercase()

        val selectedCategory =
            if (categorySpinner.selectedItem != null) {
                categorySpinner.selectedItem.toString()
            } else {
                "All Categories"
            }

        val filteredSchemes = schemes.filter {

            val searchMatch =
                it.title.lowercase().contains(searchText) ||
                        it.department.lowercase().contains(searchText) ||
                        it.category.lowercase().contains(searchText)

            val categoryMatch =
                selectedCategory == "All Categories" ||
                        it.category == selectedCategory

            searchMatch && categoryMatch
        }

        if (filteredSchemes.isEmpty()) {

            val noResult = TextView(this)

            noResult.text = "No welfare schemes found."
            noResult.textSize = 16f
            noResult.gravity = Gravity.CENTER
            noResult.setPadding(10, 30, 10, 30)

            schemeList.addView(noResult)

            return
        }

        for (scheme in filteredSchemes) {
            addSchemeCard(scheme)
        }
    }

    // ---------------- SCHEME CARD ----------------

    private fun addSchemeCard(scheme: Scheme) {

        val card = LinearLayout(this)

        card.orientation = LinearLayout.VERTICAL

        card.setPadding(20, 20, 20, 20)

        card.setBackgroundColor(Color.WHITE)

        card.elevation = 4f

        val cardParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )

        cardParams.setMargins(0, 0, 0, 20)

        card.layoutParams = cardParams

        // Title

        val title = TextView(this)

        title.text = scheme.title
        title.textSize = 18f
        title.setTextColor(Color.rgb(31, 41, 55))
        title.setTypeface(null, android.graphics.Typeface.BOLD)

        card.addView(title)

        // Department

        val department = TextView(this)

        department.text = scheme.department
        department.textSize = 14f
        department.setTextColor(Color.rgb(107, 114, 128))
        department.setPadding(0, 8, 0, 8)

        card.addView(department)

        // Description

        val description = TextView(this)

        description.text = scheme.description
        description.textSize = 15f
        description.setTextColor(Color.DKGRAY)

        card.addView(description)

        // Details button

        val detailsButton = Button(this)

        detailsButton.text = "View Details"

        detailsButton.setOnClickListener {
            showSchemeDetails(scheme)
        }

        card.addView(detailsButton)

        schemeList.addView(card)
    }

    // ---------------- SCHEME DETAILS ----------------

    private fun showSchemeDetails(scheme: Scheme) {

        val message =
            "Department:\n" +
                    scheme.department +
                    "\n\n" +

                    "Category:\n" +
                    scheme.category +
                    "\n\n" +

                    "Description:\n" +
                    scheme.description +
                    "\n\n" +

                    "Required Documents:\n" +
                    scheme.documents +
                    "\n\n" +

                    "Note:\n" +
                    "Documents may vary depending on the applicant and current government rules."

        AlertDialog.Builder(this)
            .setTitle(scheme.title)
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }

    // ---------------- ELIGIBILITY ----------------

    private fun showEligibility() {

        val input = EditText(this)

        input.hint = "Enter your age"

        input.inputType =
            InputType.TYPE_CLASS_NUMBER

        val container = LinearLayout(this)

        container.orientation =
            LinearLayout.VERTICAL

        container.setPadding(40, 10, 40, 0)

        container.addView(input)

        AlertDialog.Builder(this)
            .setTitle("Check Eligibility")
            .setMessage(
                "Enter your age for a basic eligibility check."
            )
            .setView(container)

            .setPositiveButton("Check") { _, _ ->

                val ageText =
                    input.text.toString().trim()

                if (ageText.isEmpty()) {

                    Toast.makeText(
                        this,
                        "Please enter your age.",
                        Toast.LENGTH_SHORT
                    ).show()

                } else {

                    val age = ageText.toInt()

                    if (age in 21..70) {

                        AlertDialog.Builder(this)
                            .setTitle("Eligibility Result")
                            .setMessage(
                                "You are Eligible!"
                            )
                            .setPositiveButton(
                                "OK",
                                null
                            )
                            .show()

                    } else {

                        AlertDialog.Builder(this)
                            .setTitle("Eligibility Result")
                            .setMessage(
                                "You are Not Eligible based on the basic age check."
                            )
                            .setPositiveButton(
                                "OK",
                                null
                            )
                            .show()
                    }
                }
            }

            .setNegativeButton(
                "Cancel",
                null
            )

            .show()
    }

    // ---------------- ANALYTICS ----------------

    private fun showAnalytics() {

        searchBox.visibility = View.GONE
        categorySpinner.visibility = View.GONE

        sectionTitle.text =
            "Beneficiary Analytics"

        schemeList.removeAllViews()

        addAnalyticsBox(
            "Total Schemes",
            "10+"
        )

        addAnalyticsBox(
            "Total Beneficiaries",
            "25,000+"
        )

        addAnalyticsBox(
            "Coverage",
            "75%"
        )
    }

    private fun addAnalyticsBox(
        title: String,
        value: String
    ) {

        val box = LinearLayout(this)

        box.orientation =
            LinearLayout.VERTICAL

        box.setPadding(
            20,
            20,
            20,
            20
        )

        box.setBackgroundColor(
            Color.WHITE
        )

        box.elevation = 3f

        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )

        params.setMargins(
            0,
            0,
            0,
            20
        )

        box.layoutParams = params

        val titleText = TextView(this)

        titleText.text = title
        titleText.textSize = 16f
        titleText.setTextColor(Color.DKGRAY)

        box.addView(titleText)

        val valueText = TextView(this)

        valueText.text = value
        valueText.textSize = 28f
        valueText.setTextColor(
            Color.rgb(79, 70, 229)
        )

        valueText.setTypeface(
            null,
            android.graphics.Typeface.BOLD
        )

        box.addView(valueText)

        schemeList.addView(box)
    }

    // ---------------- ABOUT ----------------

    private fun showAbout() {

        searchBox.visibility = View.GONE
        categorySpinner.visibility = View.GONE

        sectionTitle.text =
            "About the Project"

        schemeList.removeAllViews()

        val about = TextView(this)

        about.text =
            "Maha Welfare Connect\n\n" +

                    "This application provides information " +
                    "about welfare schemes available to " +
                    "citizens in Maharashtra.\n\n" +

                    "Main Features:\n\n" +

                    "• Search welfare schemes\n" +
                    "• Filter schemes by category\n" +
                    "• View scheme details\n" +
                    "• View required documents\n" +
                    "• Check basic eligibility\n" +
                    "• View beneficiary analytics\n\n" +

                    "The project aims to make welfare " +
                    "scheme information easier to find " +
                    "and understand."

        about.textSize = 16f

        about.setTextColor(Color.DKGRAY)

        about.setPadding(
            10,
            10,
            10,
            20
        )

        schemeList.addView(about)
    }
}